<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>کلهر آسانسور</title>
    <link rel="stylesheet" href="style/style.css">
</head>

<body>
    <div class="cuntiner">
        <h1>کلهر آسانسور</h1>
        <div>
            <p>
                سایت در دست تعمیر است.
            </p>
        </div>
        <div>
            <p>
                لطفا جهت مشاوره با شماره های زیر تماس بگیرید: <br>
            </p>
        </div>
        <div class="number">
            <p>
                09362274896
            </p>
        </div>

    </div>
</body>

</html>